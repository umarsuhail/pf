
import Image from "next/image";

const navLinks = [
  'Home',
  'About Us',
  'Services',
  'Innovation',
  'Press',
  'Career',
  'Contact Us',
];

export default function NeumorphicNavbar() {
  return (


      <nav 
        className="fixed top-8 left-1/2 -translate-x-1/2 w-[95%] max-w-7xl h-20 px-4 
                   bg-gray-100 rounded-full flex items-center justify-between z-50
                   shadow-[8px_8px_16px_#d1d5db,-8px_-8px_16px_#ffffff]"
      >
        
        <a href="#home" className="pl-4">
          <Image
            src="/ef-r-logo.png"
            alt="EFR"
            width={150}
            height={52}
            priority
            className="h-10 w-auto object-contain"
          />
        </a>

        {/* Links Section (Center/Right) */}
        <div className="hidden lg:flex items-center gap-5">
          {navLinks.map((link) => (
            <button
              key={link}
              className="px-5 py-2.5 rounded-full text-sm font-semibold text-gray-600 
                         transition-all duration-300 ease-in-out bg-gray-100
                         shadow-[4px_4px_8px_#d1d5db,-4px_-4px_8px_#ffffff]
                         hover:shadow-[inset_4px_4px_8px_#d1d5db,inset_-4px_-4px_8px_#ffffff]
                         hover:text-indigo-500 focus:outline-none active:scale-95"
            >
              {link}
            </button>
          ))}
        </div>

        {/* Call to Action Button */}
        <div className="hidden md:block pr-2">
          <button
            className="px-8 py-3 rounded-full text-sm font-bold text-indigo-600 
                       transition-all duration-300 ease-in-out bg-gray-100
                       shadow-[4px_4px_8px_#d1d5db,-4px_-4px_8px_#ffffff]
                       hover:shadow-[inset_4px_4px_8px_#d1d5db,inset_-4px_-4px_8px_#ffffff]
                       active:scale-95 focus:outline-none"
          >
            Book a Demo
          </button>
        </div>

      </nav>
  );
}