
"use client";

import { useEffect } from "react";

const PHASE_SCROLL_SCREENS = 6;

const WHITE_RGB = { r: 255, g: 255, b: 255 };
const NAVY_RGB = { r: 13, g: 47, b: 96 };
const BLACK_RGB = { r: 0, g: 0, b: 0 };
const LIGHT_TEXT_RGB = { r: 232, g: 242, b: 255 };
const DARK_TEXT_RGB = { r: 15, g: 23, b: 42 };

function rgbToHex(r: number, g: number, b: number): string {
  const toHex = (v: number) => Math.round(v).toString(16).padStart(2, "0");
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function mixColor(
  start: { r: number; g: number; b: number },
  end: { r: number; g: number; b: number },
  t: number
): string {
  return rgbToHex(
    start.r + (end.r - start.r) * t,
    start.g + (end.g - start.g) * t,
    start.b + (end.b - start.b) * t
  );
}

export default function Home() {
  useEffect(() => {
    let rafId = 0;

    const updateThemeFromScroll = () => {
      const start = window.innerHeight * PHASE_SCROLL_SCREENS;
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      const span = Math.max(maxScroll - start, window.innerHeight);
      const blueProgress = Math.min(Math.max((window.scrollY - start) / span, 0), 1);

      const topColor = mixColor(WHITE_RGB, NAVY_RGB, blueProgress);
      const middleColor = mixColor(WHITE_RGB, NAVY_RGB, Math.min(blueProgress * 1.25, 1));
      const bottomColor = mixColor(NAVY_RGB, BLACK_RGB, blueProgress);
      const gradient =
        blueProgress <= 0
          ? "#ffffff"
          : `linear-gradient(180deg, ${topColor} 0%, ${middleColor} 55%, ${bottomColor} 100%)`;

      document.documentElement.style.setProperty("--background", gradient);
      document.documentElement.style.setProperty(
        "--foreground",
        mixColor(DARK_TEXT_RGB, LIGHT_TEXT_RGB, blueProgress)
      );
    };

    const onScroll = () => {
      if (rafId) return;
      rafId = requestAnimationFrame(() => {
        updateThemeFromScroll();
        rafId = 0;
      });
    };

    updateThemeFromScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });

    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      document.documentElement.style.setProperty("--background", "#ffffff");
      document.documentElement.style.setProperty("--foreground", "#0f172a");
    };
  }, []);

  return <section id="home" className="relative" style={{ minHeight: "760vh" }} />;
}

